// Taking Orders:

let orderArray = [];

// Recursive function to prompt and process order

const promptForOrder = () => {
   let userInput = prompt(
      "Please let us know what is your main ingredient that you are looking to order? e.g., Lime, Chicken..."
   );
   const userInputFormatted = userInput
      .toLowerCase()
      .trim()
      .replace(/ /g, "_"); // Replace spaces with underscores
   

   // Fetch data based on user input
   fetch(
         `https://www.themealdb.com/api/json/v1/1/filter.php?i=${userInputFormatted}`
      ) // Fetch data from API 1.2
      .then((res) => res.json())
      .then((result) => {
         if (result.meals === null) {
            alert("Meal not found. Please try again!");
            return promptForOrder(); // Retry prompt if meal not found
         } else {
            const randomItem = result.meals[Math.floor(Math.random() * result.meals.length)];

            // Generate unique order ID based on timestamp and random number
            const uniqueID = () => {
               const timestamp = Date.now().toString().slice(-4);
               const randomPart = Math.floor(Math.random() * 100);
               return timestamp + randomPart;
            };

            const orderItemNumber = orderArray.length + 1; // Count the current number of items of this order
            const orderNumber = uniqueID();

            // New order object
            const newOrder = {
               meal: randomItem.strMeal,
               orderNumber: orderNumber,
               orderItemNumber: orderItemNumber,
               status: "Incomplete"
            };

            // Add new order to order array and store in session
            orderArray.push(newOrder);
            sessionStorage.setItem("newOrder", JSON.stringify(orderArray));

            // Save last order as seperate value and store in session
            const lastOrder = orderArray[orderArray.length - 1];
            sessionStorage.setItem("lastOrder", JSON.stringify(lastOrder));


            alert(`You have ordered - ${randomItem.strMeal}\n Order Number: ${orderNumber}\n Status: ${newOrder.status}`);


            // Ask user if they want to place another order
            const userResponse = confirm(
               "Do you want to order anything else?"
            );

            // Check the user's response
            if (userResponse) {
               return promptForOrder();
            } else {
               markOrderAsComplete();
            }
         }
      })
      .catch((error) => console.error("Fetch error:", error));


};


// Mark orders as completed

const markOrderAsComplete = () => {
   let orderNameNumber = "";

   //Only display order Incompleted
   const inProgressOrders = orderArray.filter(order => order.status === "Incomplete");

   inProgressOrders.forEach(order => {
    orderNameNumber += `Meal: ${order.meal}\n`;
    orderNameNumber += `Order Number: ${order.orderNumber}\n`;
    });


   let markOrderComplete = prompt(`Thank you for placing your order.\n\nHere is your breakdown of all incompleted order/s:\n\n${orderNameNumber}\n\nPlease enter the Order Number to mark the order as completed or enter "0" if your order/s is still incompleted?`

   );


   // Find the index of the order in the orderArray
   const orderIndex = orderArray.findIndex(order => order.orderNumber === markOrderComplete);

   // Check if the order was found
   if (markOrderComplete === "0") { //Prompt return a string 
      alert("Thank you for your order!");
      return;
   } else if (orderIndex === -1) {
      alert("Incorrect Order Number. Please try again!");
      markOrderAsComplete(); // Recursion if order number is incorrect
   } else {
      orderArray[orderIndex].status = "Complete";
      alert(`Order Number ${markOrderComplete} has been marked as completed!`);
      sessionStorage.setItem("newOrder", JSON.stringify(orderArray));
      console.log(orderArray); // Log the current orders to the console
   }

   const replyFromUser = confirm("Do you have another order you would like to mark as completed");
   if (replyFromUser === false) {
      alert("Thank you for your order!");
      return;
   } else {
      markOrderAsComplete();
   }

};


promptForOrder();